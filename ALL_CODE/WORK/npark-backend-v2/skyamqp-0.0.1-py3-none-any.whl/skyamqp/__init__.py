__version__ = '0.0.1'

from skyamqp.amqp_client import AMQP_Client
